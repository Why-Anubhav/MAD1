import os
from datetime import date
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.utils import secure_filename
from models import get_db

student_bp = Blueprint("student", __name__, url_prefix="/student")
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "uploads")
ALLOWED_EXT = {"pdf", "doc", "docx"}


def student_required(f):
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get("role") != "student":
            flash("Student access required.", "danger")
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)
    return wrapper


def get_student_id():
    db = get_db()
    row = db.execute("SELECT student_id FROM students WHERE user_id=?", (session["user_id"],)).fetchone()
    db.close()
    return row["student_id"] if row else None


@student_bp.route("/dashboard")
@student_required
def dashboard():
    sid = get_student_id()
    db = get_db()
    profile = db.execute("""
        SELECT s.*, u.name, u.email FROM students s JOIN users u ON s.user_id=u.id
        WHERE s.student_id=?
    """, (sid,)).fetchone()
    apps = db.execute("""
        SELECT a.application_status, COUNT(*) AS cnt FROM applications a
        WHERE a.student_id=? GROUP BY a.application_status
    """, (sid,)).fetchall()
    recent = db.execute("""
        SELECT a.*, pd.job_title, c.company_name FROM applications a
        JOIN placement_drives pd ON a.drive_id = pd.drive_id
        JOIN companies c ON pd.company_id = c.company_id
        WHERE a.student_id=? ORDER BY a.application_date DESC LIMIT 5
    """, (sid,)).fetchall()
    db.close()
    status_map = {r["application_status"]: r["cnt"] for r in apps}
    return render_template("student/dashboard.html", profile=profile, status_map=status_map, recent=recent)


@student_bp.route("/drives")
@student_required
def drives():
    sid = get_student_id()
    q = request.args.get("q", "")
    db = get_db()
    if q:
        rows = db.execute("""
            SELECT pd.*, c.company_name FROM placement_drives pd
            JOIN companies c ON pd.company_id = c.company_id
            WHERE pd.drive_status='approved'
            AND (pd.job_title LIKE ? OR c.company_name LIKE ? OR pd.eligibility LIKE ?)
            ORDER BY pd.drive_id DESC
        """, (f"%{q}%", f"%{q}%", f"%{q}%")).fetchall()
    else:
        rows = db.execute("""
            SELECT pd.*, c.company_name FROM placement_drives pd
            JOIN companies c ON pd.company_id = c.company_id
            WHERE pd.drive_status='approved' ORDER BY pd.drive_id DESC
        """).fetchall()

    applied_ids = {r["drive_id"] for r in db.execute(
        "SELECT drive_id FROM applications WHERE student_id=?", (sid,)
    ).fetchall()}
    db.close()
    return render_template("student/drives.html", drives=rows, applied_ids=applied_ids, q=q)


@student_bp.route("/apply/<int:did>", methods=["POST"])
@student_required
def apply(did):
    sid = get_student_id()
    db = get_db()
    existing = db.execute(
        "SELECT application_id FROM applications WHERE student_id=? AND drive_id=?", (sid, did)
    ).fetchone()
    if existing:
        flash("You have already applied for this drive.", "warning")
    else:
        db.execute(
            "INSERT INTO applications (student_id, drive_id, application_date) VALUES (?,?,?)",
            (sid, did, str(date.today())),
        )
        db.commit()
        flash("Application submitted successfully!", "success")
    db.close()
    return redirect(url_for("student.drives"))


@student_bp.route("/applications")
@student_required
def applications():
    sid = get_student_id()
    db = get_db()
    rows = db.execute("""
        SELECT a.*, pd.job_title, pd.package, c.company_name
        FROM applications a
        JOIN placement_drives pd ON a.drive_id = pd.drive_id
        JOIN companies c ON pd.company_id = c.company_id
        WHERE a.student_id=? ORDER BY a.application_date DESC
    """, (sid,)).fetchall()
    db.close()
    return render_template("student/applications.html", applications=rows)


@student_bp.route("/profile", methods=["GET", "POST"])
@student_required
def profile():
    sid = get_student_id()
    db = get_db()
    if request.method == "POST":
        branch = request.form.get("branch", "")
        cgpa   = request.form.get("cgpa", 0)
        year   = request.form.get("graduation_year", "")
        resume = request.files.get("resume")
        resume_path = None

        if resume and resume.filename:
            ext = resume.filename.rsplit(".", 1)[-1].lower()
            if ext in ALLOWED_EXT:
                os.makedirs(UPLOAD_FOLDER, exist_ok=True)
                fname = secure_filename(f"student_{sid}_{resume.filename}")
                save_path = os.path.join(UPLOAD_FOLDER, fname)
                resume.save(save_path)
                resume_path = f"uploads/{fname}"
            else:
                flash("Only PDF/DOC/DOCX resumes allowed.", "danger")

        if resume_path:
            db.execute(
                "UPDATE students SET branch=?, cgpa=?, graduation_year=?, resume_path=? WHERE student_id=?",
                (branch, cgpa, year, resume_path, sid),
            )
        else:
            db.execute(
                "UPDATE students SET branch=?, cgpa=?, graduation_year=? WHERE student_id=?",
                (branch, cgpa, year, sid),
            )
        db.commit()
        flash("Profile updated.", "success")

    profile = db.execute("""
        SELECT s.*, u.name, u.email FROM students s JOIN users u ON s.user_id=u.id
        WHERE s.student_id=?
    """, (sid,)).fetchone()
    db.close()
    return render_template("student/profile.html", profile=profile)
