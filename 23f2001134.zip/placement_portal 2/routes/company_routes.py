from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from models import get_db
from functools import wraps

company_bp = Blueprint("company", __name__, url_prefix="/company")


def company_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get("role") != "company":
            flash("Company access required.", "danger")
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)
    return wrapper


def get_company_id():
    db = get_db()
    row = db.execute("SELECT company_id FROM companies WHERE user_id=?", (session["user_id"],)).fetchone()
    db.close()
    return row["company_id"] if row else None


@company_bp.route("/dashboard")
@company_required
def dashboard():
    cid = get_company_id()
    db = get_db()
    info = db.execute("""
        SELECT c.*, u.name, u.email FROM companies c JOIN users u ON c.user_id=u.id
        WHERE c.company_id=?
    """, (cid,)).fetchone()
    stats = {
        "drives":       db.execute("SELECT COUNT(*) AS n FROM placement_drives WHERE company_id=?", (cid,)).fetchone()["n"],
        "applications": db.execute("""
            SELECT COUNT(*) AS n FROM applications a
            JOIN placement_drives pd ON a.drive_id=pd.drive_id WHERE pd.company_id=?
        """, (cid,)).fetchone()["n"],
        "selected": db.execute("""
            SELECT COUNT(*) AS n FROM applications a
            JOIN placement_drives pd ON a.drive_id=pd.drive_id
            WHERE pd.company_id=? AND a.application_status='Selected'
        """, (cid,)).fetchone()["n"],
    }
    drives = db.execute(
        "SELECT * FROM placement_drives WHERE company_id=? ORDER BY drive_id DESC LIMIT 5", (cid,)
    ).fetchall()
    db.close()
    return render_template("company/dashboard.html", info=info, stats=stats, drives=drives)


@company_bp.route("/drives")
@company_required
def drives():
    cid = get_company_id()
    db = get_db()
    rows = db.execute("SELECT * FROM placement_drives WHERE company_id=? ORDER BY drive_id DESC", (cid,)).fetchall()
    db.close()
    return render_template("company/drives.html", drives=rows)


@company_bp.route("/drives/new", methods=["GET", "POST"])
@company_required
def new_drive():
    cid = get_company_id()
    if request.method == "POST":
        title    = request.form.get("job_title", "").strip()
        desc     = request.form.get("job_description", "")
        elig     = request.form.get("eligibility", "")
        pkg      = request.form.get("package", "")
        deadline = request.form.get("application_deadline", "")

        if not title:
            flash("Job title is required.", "danger")
            return render_template("company/drive_form.html", drive=None)

        db = get_db()
        db.execute("""
            INSERT INTO placement_drives (company_id, job_title, job_description, eligibility, package, application_deadline)
            VALUES (?,?,?,?,?,?)
        """, (cid, title, desc, elig, pkg, deadline))
        db.commit()
        db.close()
        flash("Drive submitted for admin approval.", "success")
        return redirect(url_for("company.drives"))

    return render_template("company/drive_form.html", drive=None)


@company_bp.route("/drives/<int:did>/edit", methods=["GET", "POST"])
@company_required
def edit_drive(did):
    cid = get_company_id()
    db = get_db()
    drive = db.execute("SELECT * FROM placement_drives WHERE drive_id=? AND company_id=?", (did, cid)).fetchone()
    if not drive:
        db.close()
        flash("Drive not found.", "danger")
        return redirect(url_for("company.drives"))

    if request.method == "POST":
        title    = request.form.get("job_title", "").strip()
        desc     = request.form.get("job_description", "")
        elig     = request.form.get("eligibility", "")
        pkg      = request.form.get("package", "")
        deadline = request.form.get("application_deadline", "")
        db.execute("""
            UPDATE placement_drives SET job_title=?, job_description=?, eligibility=?,
            package=?, application_deadline=?, drive_status='pending' WHERE drive_id=?
        """, (title, desc, elig, pkg, deadline, did))
        db.commit()
        db.close()
        flash("Drive updated and resubmitted for approval.", "success")
        return redirect(url_for("company.drives"))

    db.close()
    return render_template("company/drive_form.html", drive=drive)


@company_bp.route("/drives/<int:did>/applicants")
@company_required
def applicants(did):
    cid = get_company_id()
    db = get_db()
    drive = db.execute("SELECT * FROM placement_drives WHERE drive_id=? AND company_id=?", (did, cid)).fetchone()
    if not drive:
        db.close()
        flash("Drive not found.", "danger")
        return redirect(url_for("company.drives"))
    rows = db.execute("""
        SELECT a.*, u.name AS student_name, u.email, s.branch, s.cgpa, s.resume_path, s.student_id AS sid
        FROM applications a
        JOIN students s ON a.student_id = s.student_id
        JOIN users u    ON s.user_id    = u.id
        WHERE a.drive_id=? ORDER BY a.application_date
    """, (did,)).fetchall()
    db.close()
    return render_template("company/applicants.html", applicants=rows, drive=drive)


@company_bp.route("/applications/<int:aid>/status", methods=["POST"])
@company_required
def update_status(aid):
    status = request.form.get("status")
    valid  = ("Shortlisted", "Selected", "Rejected")
    if status not in valid:
        flash("Invalid status.", "danger")
        return redirect(url_for("company.drives"))
    db = get_db()
    db.execute("UPDATE applications SET application_status=? WHERE application_id=?", (status, aid))
    db.commit()
    did = db.execute("SELECT drive_id FROM applications WHERE application_id=?", (aid,)).fetchone()["drive_id"]
    db.close()
    flash(f"Status updated to {status}.", "success")
    return redirect(url_for("company.applicants", did=did))
