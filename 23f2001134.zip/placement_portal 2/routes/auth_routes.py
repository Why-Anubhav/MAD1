from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from models import get_db

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/")
def index():
    return redirect(url_for("auth.login"))


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email    = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        db.close()

        if not user or not check_password_hash(user["password"], password):
            flash("Invalid email or password.", "danger")
            return render_template("login.html")

        # Companies must be approved before they can log in
        if user["role"] == "company":
            db2 = get_db()
            co = db2.execute(
                "SELECT approval_status FROM companies WHERE user_id=?", (user["id"],)
            ).fetchone()
            db2.close()
            if not co or co["approval_status"] != "approved":
                flash("Your company account is pending admin approval.", "warning")
                return render_template("login.html")

        session["user_id"]   = user["id"]
        session["user_name"] = user["name"]
        session["role"]      = user["role"]

        if user["role"] == "admin":
            return redirect(url_for("admin.dashboard"))
        elif user["role"] == "student":
            return redirect(url_for("student.dashboard"))
        else:
            return redirect(url_for("company.dashboard"))

    return render_template("login.html")


@auth_bp.route("/register/student", methods=["GET", "POST"])
def register_student():
    if request.method == "POST":
        name   = request.form.get("name", "").strip()
        email  = request.form.get("email", "").strip()
        pwd    = request.form.get("password", "")
        branch = request.form.get("branch", "")
        cgpa   = request.form.get("cgpa", 0)
        year   = request.form.get("graduation_year", "")

        if not all([name, email, pwd]):
            flash("All fields are required.", "danger")
            return render_template("register_student.html")

        db = get_db()
        try:
            db.execute(
                "INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)",
                (name, email, generate_password_hash(pwd), "student"),
            )
            uid = db.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()["id"]
            db.execute(
                "INSERT INTO students (user_id,branch,cgpa,graduation_year) VALUES (?,?,?,?)",
                (uid, branch, cgpa, year),
            )
            db.commit()
            flash("Registration successful! Please log in.", "success")
            return redirect(url_for("auth.login"))
        except Exception as e:
            db.rollback()
            flash(f"Email already registered or error: {e}", "danger")
        finally:
            db.close()

    return render_template("register_student.html")


@auth_bp.route("/register/company", methods=["GET", "POST"])
def register_company():
    if request.method == "POST":
        name        = request.form.get("name", "").strip()
        email       = request.form.get("email", "").strip()
        pwd         = request.form.get("password", "")
        co_name     = request.form.get("company_name", "").strip()
        hr_contact  = request.form.get("hr_contact", "")
        website     = request.form.get("website", "")

        if not all([name, email, pwd, co_name]):
            flash("All required fields must be filled.", "danger")
            return render_template("register_company.html")

        db = get_db()
        try:
            db.execute(
                "INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)",
                (name, email, generate_password_hash(pwd), "company"),
            )
            uid = db.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()["id"]
            db.execute(
                "INSERT INTO companies (user_id,company_name,hr_contact,website) VALUES (?,?,?,?)",
                (uid, co_name, hr_contact, website),
            )
            db.commit()
            flash("Company registered! Await admin approval before logging in.", "success")
            return redirect(url_for("auth.login"))
        except Exception as e:
            db.rollback()
            flash(f"Email already registered or error: {e}", "danger")
        finally:
            db.close()

    return render_template("register_company.html")


@auth_bp.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))
