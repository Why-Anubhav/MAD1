from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from models import get_db
from functools import wraps

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Admin access required.", "danger")
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)
    return wrapper


@admin_bp.route("/dashboard")
@admin_required
def dashboard():
    db = get_db()
    stats = {
        "students":     db.execute("SELECT COUNT(*) AS c FROM students").fetchone()["c"],
        "companies":    db.execute("SELECT COUNT(*) AS c FROM companies WHERE approval_status='approved'").fetchone()["c"],
        "drives":       db.execute("SELECT COUNT(*) AS c FROM placement_drives").fetchone()["c"],
        "applications": db.execute("SELECT COUNT(*) AS c FROM applications").fetchone()["c"],
        "pending_cos":  db.execute("SELECT COUNT(*) AS c FROM companies WHERE approval_status='pending'").fetchone()["c"],
        "pending_drv":  db.execute("SELECT COUNT(*) AS c FROM placement_drives WHERE drive_status='pending'").fetchone()["c"],
    }
    recent_apps = db.execute("""
        SELECT a.application_id, u.name AS student_name, pd.job_title,
               c.company_name, a.application_status, a.application_date
        FROM applications a
        JOIN students s  ON a.student_id = s.student_id
        JOIN users u     ON s.user_id    = u.id
        JOIN placement_drives pd ON a.drive_id = pd.drive_id
        JOIN companies c ON pd.company_id = c.company_id
        ORDER BY a.application_date DESC LIMIT 10
    """).fetchall()
    db.close()
    return render_template("admin/dashboard.html", stats=stats, recent_apps=recent_apps)


@admin_bp.route("/companies")
@admin_required
def companies():
    q = request.args.get("q", "")
    db = get_db()
    if q:
        rows = db.execute("""
            SELECT c.*, u.name, u.email FROM companies c JOIN users u ON c.user_id=u.id
            WHERE c.company_name LIKE ? OR u.email LIKE ?
        """, (f"%{q}%", f"%{q}%")).fetchall()
    else:
        rows = db.execute("""
            SELECT c.*, u.name, u.email FROM companies c JOIN users u ON c.user_id=u.id
            ORDER BY c.company_id DESC
        """).fetchall()
    db.close()
    return render_template("admin/companies.html", companies=rows, q=q)


@admin_bp.route("/companies/<int:cid>/approve", methods=["POST"])
@admin_required
def approve_company(cid):
    action = request.form.get("action")
    status = "approved" if action == "approve" else "rejected"
    db = get_db()
    db.execute("UPDATE companies SET approval_status=? WHERE company_id=?", (status, cid))
    db.commit()
    db.close()
    flash(f"Company {status}.", "success")
    return redirect(url_for("admin.companies"))


@admin_bp.route("/students")
@admin_required
def students():
    q = request.args.get("q", "")
    db = get_db()
    if q:
        rows = db.execute("""
            SELECT s.*, u.name, u.email FROM students s JOIN users u ON s.user_id=u.id
            WHERE u.name LIKE ? OR u.email LIKE ? OR s.branch LIKE ?
        """, (f"%{q}%", f"%{q}%", f"%{q}%")).fetchall()
    else:
        rows = db.execute("""
            SELECT s.*, u.name, u.email FROM students s JOIN users u ON s.user_id=u.id
            ORDER BY s.student_id DESC
        """).fetchall()
    db.close()
    return render_template("admin/students.html", students=rows, q=q)


@admin_bp.route("/students/<int:sid>/delete", methods=["POST"])
@admin_required
def delete_student(sid):
    db = get_db()
    uid = db.execute("SELECT user_id FROM students WHERE student_id=?", (sid,)).fetchone()
    if uid:
        db.execute("DELETE FROM users WHERE id=?", (uid["user_id"],))
        db.commit()
    db.close()
    flash("Student deleted.", "success")
    return redirect(url_for("admin.students"))


@admin_bp.route("/drives")
@admin_required
def drives():
    db = get_db()
    rows = db.execute("""
        SELECT pd.*, c.company_name FROM placement_drives pd
        JOIN companies c ON pd.company_id = c.company_id
        ORDER BY pd.drive_id DESC
    """).fetchall()
    db.close()
    return render_template("admin/drives.html", drives=rows)


@admin_bp.route("/drives/<int:did>/approve", methods=["POST"])
@admin_required
def approve_drive(did):
    action = request.form.get("action")
    status = "approved" if action == "approve" else "rejected"
    db = get_db()
    db.execute("UPDATE placement_drives SET drive_status=? WHERE drive_id=?", (status, did))
    db.commit()
    db.close()
    flash(f"Drive {status}.", "success")
    return redirect(url_for("admin.drives"))


@admin_bp.route("/applications")
@admin_required
def applications():
    db = get_db()
    rows = db.execute("""
        SELECT a.*, u.name AS student_name, pd.job_title, c.company_name
        FROM applications a
        JOIN students s  ON a.student_id = s.student_id
        JOIN users u     ON s.user_id    = u.id
        JOIN placement_drives pd ON a.drive_id = pd.drive_id
        JOIN companies c ON pd.company_id = c.company_id
        ORDER BY a.application_date DESC
    """).fetchall()
    db.close()
    return render_template("admin/applications.html", applications=rows)


@admin_bp.route("/companies/<int:cid>/delete", methods=["POST"])
@admin_required
def delete_company(cid):
    db = get_db()
    uid = db.execute("SELECT user_id FROM companies WHERE company_id=?", (cid,)).fetchone()
    if uid:
        db.execute("DELETE FROM users WHERE id=?", (uid["user_id"],))
        db.commit()
    db.close()
    flash("Company deleted.", "success")
    return redirect(url_for("admin.companies"))
